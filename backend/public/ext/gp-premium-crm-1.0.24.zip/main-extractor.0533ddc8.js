(function(define) {
    var __define;
    typeof define === "function" && (__define = define, define = null);
    // modules are defined as an array
    // [ module function, map of requires ]
    //
    // map of requires is short require name -> numeric require
    //
    // anything defined in a previous bundle is accessed via the
    // orig method which is the require for previous bundles
    (function(modules, entry, mainEntry, parcelRequireName, globalName) {
        /* eslint-disable no-undef */ var globalObject = typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {};
        /* eslint-enable no-undef */ // Save the require from previous bundle to this closure if any
        var previousRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
        var cache = previousRequire.cache || {};
        // Do not use `require` to prevent Webpack from trying to bundle this call
        var nodeRequire = typeof module !== 'undefined' && typeof module.require === 'function' && module.require.bind(module);
        function newRequire(name, jumped) {
            if (!cache[name]) {
                if (!modules[name]) {
                    // if we cannot find the module within our internal map or
                    // cache jump to the current global require ie. the last bundle
                    // that was added to the page.
                    var currentRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
                    if (!jumped && currentRequire) {
                        return currentRequire(name, true);
                    }
                    // If there are other bundles on this page the require from the
                    // previous one is saved to 'previousRequire'. Repeat this as
                    // many times as there are bundles until the module is found or
                    // we exhaust the require chain.
                    if (previousRequire) {
                        return previousRequire(name, true);
                    }
                    // Try the node require function if it exists.
                    if (nodeRequire && typeof name === 'string') {
                        return nodeRequire(name);
                    }
                    var err = new Error("Cannot find module '" + name + "'");
                    err.code = 'MODULE_NOT_FOUND';
                    throw err;
                }
                localRequire.resolve = resolve;
                localRequire.cache = {};
                var module1 = cache[name] = new newRequire.Module(name);
                modules[name][0].call(module1.exports, localRequire, module1, module1.exports, this);
            }
            return cache[name].exports;
            function localRequire(x) {
                var res = localRequire.resolve(x);
                return res === false ? {} : newRequire(res);
            }
            function resolve(x) {
                var id = modules[name][1][x];
                return id != null ? id : x;
            }
        }
        function Module(moduleName) {
            this.id = moduleName;
            this.bundle = newRequire;
            this.exports = {};
        }
        newRequire.isParcelRequire = true;
        newRequire.Module = Module;
        newRequire.modules = modules;
        newRequire.cache = cache;
        newRequire.parent = previousRequire;
        newRequire.register = function(id, exports1) {
            modules[id] = [
                function(require, module1) {
                    module1.exports = exports1;
                },
                {}
            ];
        };
        Object.defineProperty(newRequire, 'root', {
            get: function() {
                return globalObject[parcelRequireName];
            }
        });
        globalObject[parcelRequireName] = newRequire;
        for(var i = 0; i < entry.length; i++){
            newRequire(entry[i]);
        }
        if (mainEntry) {
            // Expose entry point to Node, AMD or browser globals
            // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
            var mainExports = newRequire(mainEntry);
            // CommonJS
            if (typeof exports === 'object' && typeof module !== 'undefined') {
                module.exports = mainExports;
            // RequireJS
            } else if (typeof define === 'function' && define.amd) {
                define(function() {
                    return mainExports;
                });
            // <script>
            } else if (globalName) {
                this[globalName] = mainExports;
            }
        }
    })({
        "eCAZf": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                parcelHelpers.export(exports1, "config", ()=>config);
                const config = {
                    matches: [
                        "https://web.whatsapp.com/*"
                    ],
                    world: "MAIN",
                    run_at: "document_idle"
                };
                // Envia logs de depura\u00e7\u00e3o em tempo real direcionados ao backend
                const logMain = (nivel, mensagem, erro)=>{
                    try {
                        window.postMessage({
                            type: "CRM_LOG",
                            nivel,
                            escopo: "main-world",
                            mensagem,
                            erro: erro ? {
                                message: erro.message,
                                stack: erro.stack
                            } : undefined
                        }, "*");
                    } catch (e) {
                        console.error("[CRM-Main-Logs-Fallback]", mensagem, erro || "");
                    }
                };
                // === Resolve @lid -> n\u00famero REAL usando o Store interno do WhatsApp Web ===
                // O WhatsApp esconde o n\u00famero atr\u00e1s de @lid, MAS o navegador tem o n\u00famero de verdade
                // (precisa dele pra enviar). A fun\u00e7\u00e3o interna Store.LidUtils.getPhoneNumber devolve o
                // n\u00famero real. Isso s\u00f3 funciona AQUI (no navegador) \u2014 no servidor o WhatsApp bloqueia.
                // \u00c9 o mesmo m\u00e9todo que o whatsapp-web.js/wa-js usam.
                function resolverLidsViaStore(contatos) {
                    return new Promise((resolve)=>{
                        try {
                            const lids = (contatos || []).filter((c)=>c && c.jidLid);
                            if (lids.length === 0 || !window.webpackChunkwhatsapp_web_client) {
                                resolve(contatos);
                                return;
                            }
                            const rid = "lidres" + Math.random().toString(36).slice(2, 8);
                            window.webpackChunkwhatsapp_web_client.push([
                                [
                                    rid
                                ],
                                {},
                                (require)=>{
                                    let lidUtils = null, widFactory = null;
                                    try {
                                        const mods = require.c;
                                        for(const k in mods)try {
                                            const ex = mods[k] && mods[k].exports;
                                            if (!ex) continue;
                                            for (const c of [
                                                ex,
                                                ex.default
                                            ]){
                                                if (!c) continue;
                                                if (!lidUtils && typeof c.getPhoneNumber === "function") lidUtils = c;
                                                if (!widFactory && typeof c.createWid === "function") widFactory = c;
                                            }
                                            if (lidUtils && widFactory) break;
                                        } catch (e) {}
                                    } catch (e) {}
                                    let resolvidos = 0;
                                    if (lidUtils && typeof lidUtils.getPhoneNumber === "function") {
                                        for (const c of lids)try {
                                            let wid = c.jidLid;
                                            if (widFactory && typeof widFactory.createWid === "function") try {
                                                wid = widFactory.createWid(c.jidLid);
                                            } catch (e) {
                                                wid = c.jidLid;
                                            }
                                            const pn = lidUtils.getPhoneNumber(wid);
                                            if (pn) {
                                                const s = pn._serialized || pn.user || String(pn);
                                                const num = String(s).split("@")[0].replace(/\D/g, "");
                                                if (num && num.length >= 10 && num.length <= 15) {
                                                    c.numero = num;
                                                    c.resolvidoLid = true;
                                                    resolvidos++;
                                                }
                                            }
                                        } catch (e) {}
                                    }
                                    logMain("info", `LID->numero: ${resolvidos}/${lids.length} resolvidos (LidUtils ${lidUtils ? "OK" : "NAO achado"}, WidFactory ${widFactory ? "OK" : "NAO"}).`);
                                    resolve(contatos);
                                }
                            ]);
                            // Trava de seguran\u00e7a: se o webpack n\u00e3o chamar em 4s, envia como est\u00e1.
                            setTimeout(()=>resolve(contatos), 4000);
                        } catch (e) {
                            resolve(contatos);
                        }
                    });
                }
                // Resolve os @lid e S\u00d3 ENT\u00c3O envia os contatos pro content script.
                async function postarContatos(contatos) {
                    const resolvidos = await resolverLidsViaStore(contatos);
                    window.postMessage({
                        type: "CRM_CONTATOS_EXTRAIDOS",
                        contatos: resolvidos
                    }, "*");
                }
                const extrairContatosIndexedDB = async ()=>{
                    // Lista de bancos conhecidos no WA Web
                    const dbNames = [
                        "model-storage",
                        "wa-web-db",
                        "wa-web",
                        "wawc",
                        "whatsapp-web"
                    ];
                    // Tenta usar a API nativa primeiro para achar o banco correto
                    try {
                        if (indexedDB.databases) {
                            const dbs = await indexedDB.databases();
                            dbs.forEach((db)=>{
                                if (db.name && !dbNames.includes(db.name)) dbNames.push(db.name);
                            });
                        }
                    } catch (e) {}
                    let extracted = false;
                    for (const dbName of dbNames){
                        if (extracted) break;
                        await new Promise((resolve)=>{
                            const request = indexedDB.open(dbName);
                            request.onerror = ()=>resolve();
                            request.onsuccess = (event)=>{
                                const db = event.target.result;
                                try {
                                    if (!db.objectStoreNames.contains("contact")) {
                                        db.close();
                                        resolve();
                                        return;
                                    }
                                    const transaction = db.transaction("contact", "readonly");
                                    const store = transaction.objectStore("contact");
                                    const getAllReq = store.getAll();
                                    getAllReq.onsuccess = ()=>{
                                        const records = getAllReq.result;
                                        db.close();
                                        if (!Array.isArray(records)) {
                                            resolve();
                                            return;
                                        }
                                        const contatosValidos = records.map((rec)=>{
                                            const id = rec.id || "";
                                            if (!id || id.includes("@g.us") || id.includes("-")) return null;
                                            const numero = id.split("@")[0];
                                            if (!numero || isNaN(Number(numero))) return null;
                                            // Ignora IDs gigantes (maiores que 13 d\u00edgitos) que pertencem a bots oficiais de servi\u00e7os 
                                            // do WhatsApp, canais de transmiss\u00e3o ou newsletters corporativas.
                                            if (numero.length > 13) return null;
                                            // O usu\u00e1rio quer apenas OS CONTATOS SALVOS NA AGENDA (n\u00e3o pessoas aleat\u00f3rias de grupos)
                                            const isSavedContact = Boolean(rec.name || rec.isMyContact);
                                            if (!isSavedContact) return null;
                                            const nome = rec.name || rec.pushname || rec.formattedName || numero;
                                            // S\u00f3 adiciona se o nome for de fato um nome (e n\u00e3o apenas o n\u00famero repetido)
                                            if (!nome || nome === numero || nome.trim() === "") return null;
                                            // Marca contatos @lid pra resolver o n\u00famero real depois (via Store do WhatsApp Web).
                                            return {
                                                nome: nome.trim(),
                                                numero: numero,
                                                jidLid: String(id).includes("@lid") ? id : null
                                            };
                                        }).filter(Boolean);
                                        if (contatosValidos.length > 0) {
                                            logMain("info", `Extra\u00eddos ${contatosValidos.length} contatos do banco ${dbName}.`);
                                            postarContatos(contatosValidos);
                                            extracted = true;
                                        }
                                        resolve();
                                    };
                                    getAllReq.onerror = ()=>{
                                        db.close();
                                        resolve();
                                    };
                                } catch (e) {
                                    db.close();
                                    resolve();
                                }
                            };
                        });
                    }
                    if (!extracted) {
                        logMain("info", "Nenhum contato no IndexedDB. Tentando Webpack...");
                        try {
                            const id = Math.random().toString(36).substring(7);
                            if (window.webpackChunkwhatsapp_web_client) window.webpackChunkwhatsapp_web_client.push([
                                [
                                    id
                                ],
                                {},
                                (require)=>{
                                    let extractedContacts = [];
                                    const modules = require.c;
                                    for(const k in modules)try {
                                        const m = modules[k].exports;
                                        if (!m) continue;
                                        // Tenta acessar m.getModelsArray ou m.default.getModelsArray ou m.models
                                        const storesToTry = [
                                            m,
                                            m.default,
                                            m.Contact,
                                            m.default?.Contact
                                        ].filter(Boolean);
                                        for (const store of storesToTry){
                                            let models = [];
                                            if (typeof store.getModelsArray === "function") models = store.getModelsArray();
                                            else if (Array.isArray(store.models)) models = store.models;
                                            else if (typeof store.getModels === "function") models = store.getModels();
                                            if (models && models.length > 5) {
                                                const firstId = models[0].id ? models[0].id._serialized || models[0].id : "";
                                                // Verifica se parece um array de contatos
                                                if (typeof firstId === "string" && firstId.includes("@c.us")) {
                                                    extractedContacts = models.map((c)=>{
                                                        const jid = c.id?._serialized || c.id || "";
                                                        if (typeof jid === "string" && jid.includes("@c.us")) {
                                                            // Filtro r\u00edgido para pegar APENAS contatos salvos na agenda
                                                            const isSaved = Boolean(c.name || c.isMyContact);
                                                            if (!isSaved) return null;
                                                            const numero = jid.split("@")[0];
                                                            if (!numero || isNaN(Number(numero))) return null;
                                                            const nome = c.name;
                                                            if (!nome || nome.trim() === "") return null;
                                                            return {
                                                                nome: nome.trim(),
                                                                numero: numero
                                                            };
                                                        }
                                                        return null;
                                                    }).filter(Boolean);
                                                    break;
                                                }
                                            }
                                        }
                                        if (extractedContacts.length > 0) break;
                                    } catch (e) {}
                                    if (extractedContacts.length > 0) {
                                        logMain("info", `Extra\u00eddos ${extractedContacts.length} contatos via Webpack Agressivo.`);
                                        postarContatos(extractedContacts);
                                    } else logMain("warn", "Falha ao extrair contatos via Webpack Agressivo.");
                                }
                            ]);
                        } catch (e) {
                            logMain("error", "Erro no fallback Webpack de contatos", e);
                        }
                    }
                };
                // Executa assim que o documento est\u00e1 pronto
                extrairContatosIndexedDB();
                // Escuta pedidos de re-extra\u00e7\u00e3o e envios silenciosos do content script principal
                window.addEventListener("message", async (event)=>{
                    if (event.data && event.data.type === "CRM_EXTRAIR_CONTATOS") {
                        logMain("info", "Re-extra\xe7\xe3o de contatos solicitada pelo content script.");
                        extrairContatosIndexedDB();
                    }
                    event.data && event.data.type;
                });
                // Re-executa a cada 60 segundos para capturar novos contatos abertos
                setInterval(extrairContatosIndexedDB, 60000);
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "f6DG4"
            }
        ],
        "f6DG4": [
            function(require, module1, exports1) {
                exports1.interopDefault = function(a) {
                    return a && a.__esModule ? a : {
                        default: a
                    };
                };
                exports1.defineInteropFlag = function(a) {
                    Object.defineProperty(a, "__esModule", {
                        value: true
                    });
                };
                exports1.exportAll = function(source, dest) {
                    Object.keys(source).forEach(function(key) {
                        if (key === "default" || key === "__esModule" || dest.hasOwnProperty(key)) return;
                        Object.defineProperty(dest, key, {
                            enumerable: true,
                            get: function() {
                                return source[key];
                            }
                        });
                    });
                    return dest;
                };
                exports1.export = function(dest, destName, get) {
                    Object.defineProperty(dest, destName, {
                        enumerable: true,
                        get: get
                    });
                };
            },
            {}
        ]
    }, [
        "eCAZf"
    ], "eCAZf", "parcelRequired9e1");
    globalThis.define = __define;
})(globalThis.define);
