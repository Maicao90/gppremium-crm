(function(define) {
    var __define;
    typeof define === "function" && (__define = define, define = null);
    // modules are defined as an array
    // [ module function, map of requires ]
    //
    // map of requires is short require name -> numeric require
    //
    // anything defined in a previous bundle is accessed via the
    // orig method which is the require for previous bundles
    (function(modules, entry, mainEntry, parcelRequireName, globalName) {
        /* eslint-disable no-undef */ var globalObject = typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {};
        /* eslint-enable no-undef */ // Save the require from previous bundle to this closure if any
        var previousRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
        var cache = previousRequire.cache || {};
        // Do not use `require` to prevent Webpack from trying to bundle this call
        var nodeRequire = typeof module !== 'undefined' && typeof module.require === 'function' && module.require.bind(module);
        function newRequire(name, jumped) {
            if (!cache[name]) {
                if (!modules[name]) {
                    // if we cannot find the module within our internal map or
                    // cache jump to the current global require ie. the last bundle
                    // that was added to the page.
                    var currentRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
                    if (!jumped && currentRequire) {
                        return currentRequire(name, true);
                    }
                    // If there are other bundles on this page the require from the
                    // previous one is saved to 'previousRequire'. Repeat this as
                    // many times as there are bundles until the module is found or
                    // we exhaust the require chain.
                    if (previousRequire) {
                        return previousRequire(name, true);
                    }
                    // Try the node require function if it exists.
                    if (nodeRequire && typeof name === 'string') {
                        return nodeRequire(name);
                    }
                    var err = new Error("Cannot find module '" + name + "'");
                    err.code = 'MODULE_NOT_FOUND';
                    throw err;
                }
                localRequire.resolve = resolve;
                localRequire.cache = {};
                var module1 = cache[name] = new newRequire.Module(name);
                modules[name][0].call(module1.exports, localRequire, module1, module1.exports, this);
            }
            return cache[name].exports;
            function localRequire(x) {
                var res = localRequire.resolve(x);
                return res === false ? {} : newRequire(res);
            }
            function resolve(x) {
                var id = modules[name][1][x];
                return id != null ? id : x;
            }
        }
        function Module(moduleName) {
            this.id = moduleName;
            this.bundle = newRequire;
            this.exports = {};
        }
        newRequire.isParcelRequire = true;
        newRequire.Module = Module;
        newRequire.modules = modules;
        newRequire.cache = cache;
        newRequire.parent = previousRequire;
        newRequire.register = function(id, exports1) {
            modules[id] = [
                function(require, module1) {
                    module1.exports = exports1;
                },
                {}
            ];
        };
        Object.defineProperty(newRequire, 'root', {
            get: function() {
                return globalObject[parcelRequireName];
            }
        });
        globalObject[parcelRequireName] = newRequire;
        for(var i = 0; i < entry.length; i++){
            newRequire(entry[i]);
        }
        if (mainEntry) {
            // Expose entry point to Node, AMD or browser globals
            // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
            var mainExports = newRequire(mainEntry);
            // CommonJS
            if (typeof exports === 'object' && typeof module !== 'undefined') {
                module.exports = mainExports;
            // RequireJS
            } else if (typeof define === 'function' && define.amd) {
                define(function() {
                    return mainExports;
                });
            // <script>
            } else if (globalName) {
                this[globalName] = mainExports;
            }
        }
    })({
        "bB3r2": [
            function(require, module1, exports1) {
                require("5ca8825518260b5d").register(JSON.parse('{"abzv4":"index.js","9h2ag":"main-extractor.0533ddc8.js"}'));
            },
            {
                "5ca8825518260b5d": "e0BGj"
            }
        ],
        "e0BGj": [
            function(require, module1, exports1) {
                "use strict";
                var mapping = {};
                function register(pairs) {
                    var keys = Object.keys(pairs);
                    for(var i = 0; i < keys.length; i++)mapping[keys[i]] = pairs[keys[i]];
                }
                function resolve(id) {
                    var resolved = mapping[id];
                    if (resolved == null) throw new Error("Could not resolve bundle with id " + id);
                    return resolved;
                }
                module1.exports.register = register;
                module1.exports.resolve = resolve;
            },
            {}
        ],
        "kgW6q": [
            function(require, module1, exports1) {
                var _mainWorldScripts = require("./main-world-scripts");
            },
            {
                "./main-world-scripts": "8ZbMf"
            }
        ],
        "8ZbMf": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                var _mainExtractor = require("url:../../../src/contents/main-extractor");
                var _mainExtractorDefault = parcelHelpers.interopDefault(_mainExtractor);
                chrome.scripting.registerContentScripts([
                    {
                        "id": "srcContentsMainExtractor",
                        "js": [
                            (0, _mainExtractorDefault.default).split("/").pop().split("?")[0]
                        ],
                        "matches": [
                            "https://web.whatsapp.com/*"
                        ],
                        "world": "MAIN",
                        "runAt": "document_idle"
                    }
                ]).catch((_)=>{});
            },
            {
                "url:../../../src/contents/main-extractor": "bLTXf",
                "@parcel/transformer-js/src/esmodule-helpers.js": "f6DG4"
            }
        ],
        "bLTXf": [
            function(require, module1, exports1) {
                module1.exports = require("fd03562434532f8a").getBundleURL("abzv4") + "../../" + require("3f7e2c9cee6d1155").resolve("9h2ag");
            },
            {
                "fd03562434532f8a": "e5Rdr",
                "3f7e2c9cee6d1155": "e0BGj"
            }
        ],
        "e5Rdr": [
            function(require, module1, exports1) {
                "use strict";
                var bundleURL = {};
                function getBundleURLCached(id) {
                    var value = bundleURL[id];
                    if (!value) {
                        value = getBundleURL();
                        bundleURL[id] = value;
                    }
                    return value;
                }
                function getBundleURL() {
                    try {
                        throw new Error();
                    } catch (err) {
                        var matches = ("" + err.stack).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^)\n]+/g);
                        if (matches) // Use the 3rd one, which will be a runtime in the original bundle.
                        return getBaseURL(matches[2]);
                    }
                    return "/";
                }
                function getBaseURL(url) {
                    return ("" + url).replace(/^((?:https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/.+)\/[^/]+$/, "$1") + "/";
                } // TODO: Replace uses with `new URL(url).origin` when ie11 is no longer supported.
                function getOrigin(url) {
                    var matches = ("" + url).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^/]+/);
                    if (!matches) throw new Error("Origin not found");
                    return matches[0];
                }
                exports1.getBundleURL = getBundleURLCached;
                exports1.getBaseURL = getBaseURL;
                exports1.getOrigin = getOrigin;
            },
            {}
        ],
        "f6DG4": [
            function(require, module1, exports1) {
                exports1.interopDefault = function(a) {
                    return a && a.__esModule ? a : {
                        default: a
                    };
                };
                exports1.defineInteropFlag = function(a) {
                    Object.defineProperty(a, "__esModule", {
                        value: true
                    });
                };
                exports1.exportAll = function(source, dest) {
                    Object.keys(source).forEach(function(key) {
                        if (key === "default" || key === "__esModule" || dest.hasOwnProperty(key)) return;
                        Object.defineProperty(dest, key, {
                            enumerable: true,
                            get: function() {
                                return source[key];
                            }
                        });
                    });
                    return dest;
                };
                exports1.export = function(dest, destName, get) {
                    Object.defineProperty(dest, destName, {
                        enumerable: true,
                        get: get
                    });
                };
            },
            {}
        ]
    }, [
        "bB3r2",
        "kgW6q"
    ], "kgW6q", "parcelRequired9e1");
    globalThis.define = __define;
})(globalThis.define);
